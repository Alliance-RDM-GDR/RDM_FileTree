TreeGen (File Tree Generator)
Digital Research Alliance of Canada

What this app does
- Browse any folder and display its full tree with human-readable sizes.
- Double-click items to add notes; annotations are saved to a local .descriptions.json file.
- Filter the tree by search, hide hidden/system items, and exclude file extensions.
- Live preview of the exact Markdown/Text export, including filters and notes.
- Export the tree (and summary counts/sizes) to .md or .txt.
- Switch languages (English/French); your choice is remembered.

System requirements
- Windows 10 or later, 64-bit (desktop) OR macOS 12+.
- No internet connection required.

Getting started
1) Unzip the downloaded package to any folder you control.
2) Windows: run TreeGen.exe (no install needed). macOS: open TreeGen.app.
3) Click "Select Directory" to pick a folder. Existing .descriptions.json notes in that folder load automatically.
4) Adjust filters: search bar, excluded extensions (comma-separated), and "Hide hidden/system files."
5) Double-click a file or folder to add/edit its description.
6) Switch language via the Language dropdown (top-right).
7) Export to Markdown or Plain Text using the buttons at the bottom; the export reflects your current filters and notes.

Platform-specific notes
- Windows: If SmartScreen warns about an unsigned app, choose "More info" > "Run anyway" if you trust the source. Hidden/system detection follows Windows attributes.
- macOS: If Gatekeeper blocks the app, Control-click TreeGen.app, choose "Open," then confirm. Hidden files follow the dot-prefix convention. If you ship separate Intel/Apple Silicon builds, pick the matching one.

Tips
- File/folder sizes are shown in human-friendly units (e.g., 1.2 MB).
- Hidden/system detection follows Windows attributes; on other platforms it falls back to dot-prefixed names.
- The .descriptions.json file stays beside your data and travels with the folder.
- Exclude extensions example: .zip, .csv, .tmp

Troubleshooting
- SmartScreen/AV warning: use "More info" > "Run anyway" if you trust the source.
- Gatekeeper warning: Control-click > Open, then confirm.
- Nothing appears in the tree: ensure the folder is accessible and not blocked by permissions.
- Very large trees: filters (search, exclude extensions, hide hidden) reduce noise and speed up rendering.

Support and source
- Source repo and updates: https://github.com/Alliance-RDM-GDR/RDM_FileTree
- Email: rdm-gdr@alliancecan.ca

License
- MIT License. See LICENSE in the source repository.
